<?php
require_once 'config.php';
require_admin();

// Approve / reject / delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($id !== (int)$_SESSION['user_id']) { // admin can't change their own account
        if ($action === 'approve') {
            $pdo->prepare("UPDATE users SET status='approved' WHERE id=?")->execute([$id]);
        } elseif ($action === 'reject') {
            $pdo->prepare("UPDATE users SET status='rejected' WHERE id=?")->execute([$id]);
        } elseif ($action === 'delete') {
            $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
        }
    }
    header('Location: users.php');
    exit;
}

$users = $pdo->query('SELECT * FROM users ORDER BY status="pending" DESC, created_at DESC')->fetchAll(PDO::FETCH_ASSOC);
include 'header.php';
?>
<h2>Users</h2>
<table border="1" cellpadding="5">
    <tr><th>ID</th><th>Username</th><th>Role</th><th>Status</th><th>Registered</th><th>Actions</th></tr>
    <?php foreach ($users as $u): ?>
    <tr>
        <td><?= e($u['id']) ?></td>
        <td><?= e($u['username']) ?></td>
        <td><?= e($u['role']) ?></td>
        <td><?= e($u['status']) ?></td>
        <td><?= e($u['created_at']) ?></td>
        <td>
            <?php if ($u['id'] != $_SESSION['user_id']): ?>
            <form method="post" style="display:inline" onsubmit="return confirm('Are you sure?')">
                <input type="hidden" name="id" value="<?= e($u['id']) ?>">
                <?php if ($u['status'] !== 'approved'): ?>
                    <button name="action" value="approve">Approve</button>
                <?php endif; ?>
                <?php if ($u['status'] !== 'rejected'): ?>
                    <button name="action" value="reject">Reject</button>
                <?php endif; ?>
                <button name="action" value="delete">Delete</button>
            </form>
            <?php else: ?>
                (you)
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php include 'footer.php'; ?>
