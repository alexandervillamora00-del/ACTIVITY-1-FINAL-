<?php
require_once 'config.php';
require_login();

$products = $pdo->query(
    'SELECT p.*, u.username FROM products p JOIN users u ON p.created_by = u.id ORDER BY p.id DESC'
)->fetchAll(PDO::FETCH_ASSOC);

include 'header.php';
?>
<h2>Products</h2>
<p><a href="product_form.php">Add product</a></p>
<?php if (!$products): ?>
    <p>No products yet.</p>
<?php else: ?>
<table border="1" cellpadding="5">
    <tr><th>ID</th><th>Name</th><th>Description</th><th>Quantity</th><th>Price</th><th>Added by</th><th>Updated</th><th>Actions</th></tr>
    <?php foreach ($products as $p): ?>
    <tr>
        <td><?= e($p['id']) ?></td>
        <td><?= e($p['name']) ?></td>
        <td><?= e($p['description']) ?></td>
        <td><?= e($p['quantity']) ?></td>
        <td><?= number_format($p['price'], 2) ?></td>
        <td><?= e($p['username']) ?></td>
        <td><?= e($p['updated_at']) ?></td>
        <td>
            <a href="product_form.php?id=<?= e($p['id']) ?>">Edit</a>
            <form method="post" action="product_delete.php" style="display:inline" onsubmit="return confirm('Delete this product?')">
                <input type="hidden" name="id" value="<?= e($p['id']) ?>">
                <button>Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>
<?php include 'footer.php'; ?>
