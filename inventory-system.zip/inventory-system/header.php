<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System</title>
</head>
<body>
<h1>Inventory System</h1>
<?php if (!empty($_SESSION['user_id'])): ?>
<p>
    Logged in as <?= e($_SESSION['username']) ?> (<?= e($_SESSION['role']) ?>) |
    <a href="dashboard.php">Dashboard</a> |
    <a href="products.php">Products</a> |
    <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="users.php">Users</a> |
    <?php endif; ?>
    <a href="logout.php">Logout</a>
</p>
<hr>
<?php endif; ?>
