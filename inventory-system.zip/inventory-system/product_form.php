<?php
require_once 'config.php';
require_login();

// Same page handles both Add and Edit
$id = (int)($_GET['id'] ?? 0);
$product = ['name' => '', 'description' => '', 'quantity' => 0, 'price' => '0.00'];
$error = '';

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$product) { header('Location: products.php'); exit; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $quantity    = (int)($_POST['quantity'] ?? 0);
    $price       = (float)($_POST['price'] ?? 0);

    if ($name === '') {
        $error = 'Product name is required.';
    } elseif ($quantity < 0 || $price < 0) {
        $error = 'Quantity and price cannot be negative.';
    } else {
        if ($id) {
            $pdo->prepare('UPDATE products SET name=?, description=?, quantity=?, price=? WHERE id=?')
                ->execute([$name, $description, $quantity, $price, $id]);
        } else {
            $pdo->prepare('INSERT INTO products (name, description, quantity, price, created_by) VALUES (?,?,?,?,?)')
                ->execute([$name, $description, $quantity, $price, $_SESSION['user_id']]);
        }
        header('Location: products.php');
        exit;
    }
    $product = ['name' => $name, 'description' => $description, 'quantity' => $quantity, 'price' => $price];
}
include 'header.php';
?>
<h2><?= $id ? 'Edit Product' : 'Add Product' ?></h2>
<?php if ($error): ?><p style="color:red"><?= e($error) ?></p><?php endif; ?>
<form method="post">
    <p>Name: <input type="text" name="name" placeholder="Enter name" value="<?= e($product['name']) ?>" required></p>
    <p>Description: <br><textarea name="description" rows="3" cols="30" placeholder="Enter description"><?= e($product['description']) ?></textarea></p>
    <p>Quantity: <input type="number" name="quantity" min="0" value="<?= e($product['quantity']) ?>" required></p>
    <p>Price: <input type="number" name="price" min="0" step="0.01" value="<?= e($product['price']) ?>" required></p>
    <p><button type="submit">Save</button> <a href="products.php">Cancel</a></p>
</form>
<?php include 'footer.php'; ?>
