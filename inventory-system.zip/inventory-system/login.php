<?php
require_once 'config.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, $user['password'])) {
        $error = 'Wrong username or password.';
    } elseif ($user['status'] === 'pending') {
        $error = 'Your account is still waiting for admin approval.';
    } elseif ($user['status'] === 'rejected') {
        $error = 'Your registration was rejected by the admin.';
    } else {
        session_regenerate_id(true);
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        header('Location: dashboard.php');
        exit;
    }
}
include 'header.php';
?>
<h2>Sign In</h2>
<?php if ($error): ?><p style="color:red"><?= e($error) ?></p><?php endif; ?>
<?php if (isset($_GET['registered'])): ?>
    <p>Registered! Wait for an admin to approve your account.</p>
<?php endif; ?>
<form method="post">
    <p>Username: <input type="text" name="username" placeholder="Enter username" required></p>
    <p>Password: <input type="password" name="password" placeholder="Enter password" required></p>
    <p><button type="submit">Sign In</button></p>
</form>
<p>Don't have an account? <a href="register.php">Register</a></p>
<?php include 'footer.php'; ?>
