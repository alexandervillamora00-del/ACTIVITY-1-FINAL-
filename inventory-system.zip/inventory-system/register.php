<?php
require_once 'config.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if (strlen($username) < 3) {
        $error = 'Username must be at least 3 characters.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?');
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = 'That username is already taken.';
        } else {
            // New accounts start as "pending" until an admin approves them
            $stmt = $pdo->prepare('INSERT INTO users (username, password) VALUES (?, ?)');
            $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            header('Location: login.php?registered=1');
            exit;
        }
    }
}
include 'header.php';
?>
<h2>Create your Account</h2>
<?php if ($error): ?><p style="color:red"><?= e($error) ?></p><?php endif; ?>
<form method="post">
    <p>Username: <input type="text" name="username" placeholder="Enter username" required></p>
    <p>Password: <input type="password" name="password" placeholder="Enter password" required></p>
    <p>Re-enter Password: <input type="password" name="confirm" placeholder="Re-enter password" required></p>
    <p><button type="submit">Register</button></p>
</form>
<p>Already have an account? <a href="login.php">Sign In</a></p>
<?php include 'footer.php'; ?>
