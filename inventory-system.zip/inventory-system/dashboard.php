<?php
require_once 'config.php';
require_login();

$totalProducts = $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$totalQty      = $pdo->query('SELECT COALESCE(SUM(quantity),0) FROM products')->fetchColumn();
$totalValue    = $pdo->query('SELECT COALESCE(SUM(quantity*price),0) FROM products')->fetchColumn();
$lowStock      = $pdo->query('SELECT * FROM products WHERE quantity <= 5 ORDER BY quantity ASC LIMIT 5')->fetchAll(PDO::FETCH_ASSOC);
$pendingUsers  = $pdo->query("SELECT COUNT(*) FROM users WHERE status='pending'")->fetchColumn();

include 'header.php';
?>
<h2>Dashboard</h2>
<p>Total products: <?= e($totalProducts) ?></p>
<p>Items in stock: <?= e($totalQty) ?></p>
<p>Total stock value: <?= number_format($totalValue, 2) ?></p>
<?php if ($_SESSION['role'] === 'admin'): ?>
    <p>Pending users: <?= e($pendingUsers) ?> (<a href="users.php">view</a>)</p>
<?php endif; ?>

<h3>Low stock (5 or fewer)</h3>
<?php if (!$lowStock): ?>
    <p>Nothing is running low.</p>
<?php else: ?>
    <table border="1" cellpadding="5">
        <tr><th>Name</th><th>Quantity</th></tr>
        <?php foreach ($lowStock as $p): ?>
            <tr><td><?= e($p['name']) ?></td><td><?= e($p['quantity']) ?></td></tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>
<?php include 'footer.php'; ?>
